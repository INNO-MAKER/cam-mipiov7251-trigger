/media/pi/rootfs/home/pi/uvc/vc_mipi_ov7251_driver_pi_lattice_linux5.15/vc_mipi_ov7251/vc_mipi_ov7251.o

